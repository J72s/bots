module.exports = { // Default token, can be omitted if using tokens.json
  logChannelId: '1221249421581226014', // Replace with your desired log channel ID
};