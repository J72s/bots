const utils = require('../utils');

module.exports = client => {// Adjust the path as per your project structure
    const { getRandomStatus } = utils;
    
    client.on('ready', () => {
        const randomStatus = getRandomStatus();
    
        // Set a random status
        client.user.setStatus(randomStatus)
            .then(() => console.log(`Bot status set to ${randomStatus}`))
            .catch(console.error);
    
        console.log(`Logged in as ${client.user.username}!`);
    });
}